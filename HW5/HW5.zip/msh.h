//Function for signal handling
void handler(int sig);

